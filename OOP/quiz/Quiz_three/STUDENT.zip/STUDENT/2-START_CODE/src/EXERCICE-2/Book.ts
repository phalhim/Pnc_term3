
import { Author } from "./Author";
import { Publisher } from "./Publisher";

export class Book {
    getName(author1: Author) {
        throw new Error("Method not implemented.");
    }

    authors: Author;
    publisher: Publisher;
    title: string;
    yearOfPublished: number;

    constructor(title: string, yearOfPublished: number) {
        this.title = title;
        this.yearOfPublished = yearOfPublished;
    }

    // Add an author to the book
    addAuthor(author: Author) {
        this.authors = author;
    }

    // Set publisher of book
    setPublisher(publisher: Publisher) {
        this.publisher = publisher;
    }
}
