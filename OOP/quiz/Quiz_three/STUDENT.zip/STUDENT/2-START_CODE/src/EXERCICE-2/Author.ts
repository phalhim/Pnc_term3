import { Book } from "./Book";

// TODO
export class Author {
    getBooks: any;
    constructor(private name: string) {
        this.name = name;
    }
    getName(): string{
        return this.name
    }
    getBooksFrom(author:Author) : Book[]{
        let books: Book[] = [];
        for(let book of author.getBooks()){
            books.push(book);
        }
        return books;
    }

}