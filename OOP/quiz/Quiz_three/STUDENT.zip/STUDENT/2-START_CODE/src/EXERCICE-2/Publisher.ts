// TODO
export class Publisher{
    getName: any;
    constructor(private name: string, private address: string){
        this.name = name;
        this.address = address;
    }
    getNamePublisher():string{
        return this.name
    }
}