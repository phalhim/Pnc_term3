// TODO
import { Book } from './Book';
export class Library {
    getTitle(): any {
        throw new Error("Method not implemented.");
    }
    Book: Book[]= [];
    constructor(private name: string, private address: string) {
        this.name = name;
        this.address = address;
    }
    // Add a book to the library
    addBook(book: Book) {
        this.Book.push(book) 
    }
}
