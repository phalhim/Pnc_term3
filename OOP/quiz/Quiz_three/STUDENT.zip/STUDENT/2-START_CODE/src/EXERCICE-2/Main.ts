// TODO
import { Book } from "./Book";
import { Publisher } from "./Publisher";
import { Author } from "./Author";
import {Library } from "./Library";



let book1 = new Book('OOP is the best', 2018);
let book2 =new Book('Best team ?', 2015);
let book3 = new Book('The Why not book ', 2020);

// Author
let author1 =new Author('Ronan');
let author2 =new Author('Him');

// publisher
let publisher1 =new Publisher('Sipar','Phnom Penh');
let publisher2 = new Publisher('IBC','Siem Reap');

// Library

let library = new Library('PNC LIBRARY ', 'Phnom Penh')

book1.addAuthor(author1)
book1.setPublisher(publisher1)
// console.log(book1);

library.addBook(book1)
library.addBook(book2)
library.addBook(book3)
console.log(library);




