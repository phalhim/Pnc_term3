var House = /** @class */ (function () {
    function House() {
        this.chairs = [];
    }
    /**
     * Add a chair of given ID
     * @param chairID the chair ID
     * @return the created chair
     */
    House.prototype.addChair = function (chairID) {
        // TODO
        var chair = new Chair(chairID, this);
        this.chairs.push(chair);
        return chair;
    };
    return House;
}());
var Chair = /** @class */ (function () {
    function Chair(chairId, house) {
        this.chairId = chairId;
        this.house = house;
    }
    return Chair;
}());
// MAIN
var newHouse = new House();
var newChair = newHouse.addChair(45); // Add a chair of id 45
console.log(newChair);
