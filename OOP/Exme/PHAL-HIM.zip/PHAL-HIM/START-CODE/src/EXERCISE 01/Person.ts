
export abstract class Person {
    constructor(protected name: string, protected age: number) {
        this.name = name
        this.age = age
    }
} 
