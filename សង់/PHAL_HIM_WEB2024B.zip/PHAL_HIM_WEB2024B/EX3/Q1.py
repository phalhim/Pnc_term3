#  How many type of fruit in store?
fruit =["banana", "mango", "coconut", "orange"]
sum =0
for i in range(len(fruit)):
    sum+=1
print(sum)