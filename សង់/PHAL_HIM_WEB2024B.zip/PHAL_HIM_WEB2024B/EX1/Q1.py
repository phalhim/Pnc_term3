# How much Mr. Vanda earn in week one?
moneysOfWeekOne = [10, 15, 9, 20, 5, 30, 12]
res= 0
for i in range(len(moneysOfWeekOne)):
    res+=moneysOfWeekOne[i]
print(res)
