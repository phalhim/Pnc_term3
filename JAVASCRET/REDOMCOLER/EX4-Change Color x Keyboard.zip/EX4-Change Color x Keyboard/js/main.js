const keyboardEvent = (event) => {
    // TODO 
    // https://www.w3schools.com/jsref/event_key_key.asp
}

document.addEventListener('keydown', keyboardEvent)