

document.addEventListener('click', function(event) {
  
   
})