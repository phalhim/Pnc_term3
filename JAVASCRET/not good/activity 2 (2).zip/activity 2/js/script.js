let myElement = document.getElementById('book-list');
let myElementParent = myElement.nextElementSibling
console.log(myElementParent)