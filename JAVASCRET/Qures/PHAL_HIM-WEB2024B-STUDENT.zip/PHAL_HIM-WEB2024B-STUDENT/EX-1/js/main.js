const createPoster = () => {
   // TODO: Create poster here
 
}

// Main code 
const container = document.querySelector('.container');
// TODO:  Call function to create 10 poster here

   const divs = document.createElement('div')
   divs.className = 'poster'
   divs.textContent = 'កង្រីជាតិថ្មី'

   container.appendChild(divs)

   const text = document.createElement('div')
   text.className = 'poster-text'
   text.textContent = ' រឿងព្រេងខ្មែរ​ ជារឿងនិទានប្រកបដោយគតិអប់រំទាក់ទិននឹងសីលធម៌សង្គម និងសៀវភៅរូបភាពសំរាប់កុមារជាដើម។'

   divs.appendChild(text)

   const img = document.createElement('img');
   img.src = "images/poster.jpg";
   divs.appendChild(img)


