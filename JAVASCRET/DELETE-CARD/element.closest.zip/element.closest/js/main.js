const paragraph = document.querySelector('p');
const closestDiv = paragraph.closest('#inner');

console.log(closestDiv); // This will log the <div class="inner"> element
