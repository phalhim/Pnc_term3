let headingOne =document.querySelector("h1");
console.log(headingOne);

console.log(headingOne.textContent);

headingOne.textContent = 'banana';
