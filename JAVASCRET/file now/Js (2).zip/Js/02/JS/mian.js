let headingOne = document.createElement('h1');
console.log(headingOne);
headingOne.textContent = 'Banana';

document.body.appendChild(headingOne)
