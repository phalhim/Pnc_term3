const btnLeft = document.querySelector("#left");
const btnRight = document.querySelector("#right");
const img =document.querySelector("img")


btnLeft.addEventListener("click",function(){
    im
})