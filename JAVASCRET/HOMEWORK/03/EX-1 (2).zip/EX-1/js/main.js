
// Loop 6 times to get the color code by random from items in array
// https://www.w3schools.com/js/js_random.asp
