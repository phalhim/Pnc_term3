// Function 1 (the avg
function averageNum(num1, num2) {
  return (num1 + num2) / 2;
}
console.log("test function1:", averageNum(14, 16));

// Function 2 (as example)
// TODO
function string(n1, n2) {
  return n1 + n2
}
console.log("test function2:", string("ronan", " the best"));

// Function 3 (as example)
// TODO
const allEqual = all => all.every(val => val === all[0]);
const result = allEqual([4, 4, 4, 4])

console.log("test function3:", result);

// Function 4 (as example)
// TODO
function aString(verb, adjective) {
  student = { name: "ronan", age: 17 };
  return "student " + student.name + " " + verb + " " + student.age + " " + adjective;
}

console.log("test function4:", aString("is", "years old"));

// Function 5 (as example)
// TODO
function strLonger(s1, s2) {
  s1 = "aaa"
  s2 = "a"
  res = false
  if (s1 > s2)
    res = true
  return res
}
console.log("test function5:", strLonger());

// Function 6 (as example)
// TODO

console.log("test function6:");

// Function 7 (as example)
// TODO
function sumArray(row, column) {
  row = 2
  column = 3
res= [[0, 0, 0],[0, 0, 0]]
  return res
}
console.log("test function7:", sumArray(res));

// Function 8 (as example)
// TODO
console.log("test function8:");
