let numbers = [1, 3, 5, 0, 2, 0, 1, 1, 2, 3];
// TODO: 
// YOUR CODE HERE

// output: 14 becuase 3 + 5 + 1 + 2 + 3





