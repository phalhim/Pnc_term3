let text = "hello world [JavaScript] we [are] strong!";
// TODO: 
// YOUR CODE HERE

// output: hello world we strong!


