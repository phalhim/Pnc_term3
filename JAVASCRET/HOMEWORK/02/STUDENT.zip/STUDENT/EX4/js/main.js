// case 1:
let arr = [1, 3, 6, 7, 9];
// TODO: 
// YOUR CODE HERE

// output: [9, 9, 6, 7, 9]

