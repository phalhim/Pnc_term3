const hex = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, "A", "B", "C", "D", "E", "F"];

const btn = // TODO  your code here
const color = // TODO  your code here

// return the color string code like example: #f00233
function colorCode() {
   // TODO your code here
}

// return the number by random number between 0 and 16 (length of hex)
function getRandomColor() {
    //  TODO your code here
}

btn.addEventListener('click', function() {
   // TODO  your code here
});

