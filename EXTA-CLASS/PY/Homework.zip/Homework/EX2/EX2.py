fruits  = ["banana", "mango", "coconut", "orange"]
# - find position of mango (index)
count = 0
for i in range(len(fruits)):
    if fruits[i] =="mango":
        count +=1
print(count)