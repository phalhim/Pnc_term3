fruits  = ["banana", "mango", "coconut", "orange"]
# - Reverse list
fruits.reverse()
print(fruits)