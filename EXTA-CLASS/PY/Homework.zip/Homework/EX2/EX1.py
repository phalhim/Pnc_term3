
fruits  = ["banana", "mango", "coconut", "orange"]
# - How many fruits in the list
sum = 0
for i in range(len(fruits)):
    sum+=1
print(sum)


